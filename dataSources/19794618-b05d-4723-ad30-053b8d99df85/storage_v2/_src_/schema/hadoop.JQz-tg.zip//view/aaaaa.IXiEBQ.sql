create view aaaaa as
	/* ALGORITHM=UNDEFINED */
	select
		`hadoop`.`station_tbl_kevin`.`year`        as `year`,
		`hadoop`.`station_tbl_kevin`.`station`     as `station`,
		`hadoop`.`station_tbl_kevin`.`temperature` as `temperature`
	from `hadoop`.`station_tbl_kevin`;

