create view vw_sedr as
	select
		`se`.`id`        as `id`,
		`se`.`last_name` as `last_name`,
		`sd`.`name`      as `name`
	from (`briup`.`s_emp` `se` left join `briup`.`s_dept` `sd` on ((`se`.`dept_id`=`sd`.`id`)));

