create trigger tg3
	before insert
	on orders
	for each row
	begin
if new.num > 10 then
set new.num = 10;
end if;
update goods
set inventory=inventory-new.num
where goods.id=new.gid;
end;

