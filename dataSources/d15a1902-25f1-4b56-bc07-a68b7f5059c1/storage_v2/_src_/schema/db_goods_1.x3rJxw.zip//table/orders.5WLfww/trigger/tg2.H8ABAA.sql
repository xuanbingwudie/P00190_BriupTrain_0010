create trigger tg2
	after delete
	on orders
	for each row
	begin
update goods
set inventory=inventory+old.num
where goods.id=old.gid;
end;

