create view `x$session` as
	select
		`x$processlist`.`thd_id`                 as `thd_id`,
		`x$processlist`.`conn_id`                as `conn_id`,
		`x$processlist`.`user`                   as `user`,
		`x$processlist`.`db`                     as `db`,
		`x$processlist`.`command`                as `command`,
		`x$processlist`.`state`                  as `state`,
		`x$processlist`.`time`                   as `time`,
		`x$processlist`.`current_statement`      as `current_statement`,
		`x$processlist`.`statement_latency`      as `statement_latency`,
		`x$processlist`.`progress`               as `progress`,
		`x$processlist`.`lock_latency`           as `lock_latency`,
		`x$processlist`.`rows_examined`          as `rows_examined`,
		`x$processlist`.`rows_sent`              as `rows_sent`,
		`x$processlist`.`rows_affected`          as `rows_affected`,
		`x$processlist`.`tmp_tables`             as `tmp_tables`,
		`x$processlist`.`tmp_disk_tables`        as `tmp_disk_tables`,
		`x$processlist`.`full_scan`              as `full_scan`,
		`x$processlist`.`last_statement`         as `last_statement`,
		`x$processlist`.`last_statement_latency` as `last_statement_latency`,
		`x$processlist`.`current_memory`         as `current_memory`,
		`x$processlist`.`last_wait`              as `last_wait`,
		`x$processlist`.`last_wait_latency`      as `last_wait_latency`,
		`x$processlist`.`source`                 as `source`,
		`x$processlist`.`trx_latency`            as `trx_latency`,
		`x$processlist`.`trx_state`              as `trx_state`,
		`x$processlist`.`trx_autocommit`         as `trx_autocommit`,
		`x$processlist`.`pid`                    as `pid`,
		`x$processlist`.`program_name`           as `program_name`
	from `sys`.`x$processlist`
	where ((`x$processlist`.`conn_id` is not null) and (`x$processlist`.`command`<>'Daemon'));

