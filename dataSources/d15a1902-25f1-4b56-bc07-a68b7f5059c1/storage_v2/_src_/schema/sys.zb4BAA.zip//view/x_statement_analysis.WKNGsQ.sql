create view `x$statement_analysis` as
	select
		`performance_schema`.`events_statements_summary_by_digest`.`DIGEST_TEXT`                                                                                                                   as `query`,
		`performance_schema`.`events_statements_summary_by_digest`.`SCHEMA_NAME`                                                                                                                   as `db`,
		if(((`performance_schema`.`events_statements_summary_by_digest`.`SUM_NO_GOOD_INDEX_USED`>0) or (`performance_schema`.`events_statements_summary_by_digest`.`SUM_NO_INDEX_USED`>0)),'*','') as `full_scan`,
		`performance_schema`.`events_statements_summary_by_digest`.`COUNT_STAR`                                                                                                                    as `exec_count`,
		`performance_schema`.`events_statements_summary_by_digest`.`SUM_ERRORS`                                                                                                                    as `err_count`,
		`performance_schema`.`events_statements_summary_by_digest`.`SUM_WARNINGS`                                                                                                                  as `warn_count`,
		`performance_schema`.`events_statements_summary_by_digest`.`SUM_TIMER_WAIT`                                                                                                                as `total_latency`,
		`performance_schema`.`events_statements_summary_by_digest`.`MAX_TIMER_WAIT`                                                                                                                as `max_latency`,
		`performance_schema`.`events_statements_summary_by_digest`.`AVG_TIMER_WAIT`                                                                                                                as `avg_latency`,
		`performance_schema`.`events_statements_summary_by_digest`.`SUM_LOCK_TIME`                                                                                                                 as `lock_latency`,
		`performance_schema`.`events_statements_summary_by_digest`.`SUM_ROWS_SENT`                                                                                                                 as `rows_sent`,
		round(ifnull((`performance_schema`.`events_statements_summary_by_digest`.`SUM_ROWS_SENT`/nullif(`performance_schema`.`events_statements_summary_by_digest`.`COUNT_STAR`,0)),0),0)          as `rows_sent_avg`,
		`performance_schema`.`events_statements_summary_by_digest`.`SUM_ROWS_EXAMINED`                                                                                                             as `rows_examined`,
		round(ifnull((`performance_schema`.`events_statements_summary_by_digest`.`SUM_ROWS_EXAMINED`/nullif(`performance_schema`.`events_statements_summary_by_digest`.`COUNT_STAR`,0)),0),0)      as `rows_examined_avg`,
		`performance_schema`.`events_statements_summary_by_digest`.`SUM_ROWS_AFFECTED`                                                                                                             as `rows_affected`,
		round(ifnull((`performance_schema`.`events_statements_summary_by_digest`.`SUM_ROWS_AFFECTED`/nullif(`performance_schema`.`events_statements_summary_by_digest`.`COUNT_STAR`,0)),0),0)      as `rows_affected_avg`,
		`performance_schema`.`events_statements_summary_by_digest`.`SUM_CREATED_TMP_TABLES`                                                                                                        as `tmp_tables`,
		`performance_schema`.`events_statements_summary_by_digest`.`SUM_CREATED_TMP_DISK_TABLES`                                                                                                   as `tmp_disk_tables`,
		`performance_schema`.`events_statements_summary_by_digest`.`SUM_SORT_ROWS`                                                                                                                 as `rows_sorted`,
		`performance_schema`.`events_statements_summary_by_digest`.`SUM_SORT_MERGE_PASSES`                                                                                                         as `sort_merge_passes`,
		`performance_schema`.`events_statements_summary_by_digest`.`DIGEST`                                                                                                                        as `digest`,
		`performance_schema`.`events_statements_summary_by_digest`.`FIRST_SEEN`                                                                                                                    as `first_seen`,
		`performance_schema`.`events_statements_summary_by_digest`.`LAST_SEEN`                                                                                                                     as `last_seen`
	from `performance_schema`.`events_statements_summary_by_digest`
	order by `performance_schema`.`events_statements_summary_by_digest`.`SUM_TIMER_WAIT` desc;

