create view `x$ps_schema_table_statistics_io` as
	select
		`extract_schema_from_file_name`(`performance_schema`.`file_summary_by_instance`.`FILE_NAME`) as `table_schema`,
		`extract_table_from_file_name`(`performance_schema`.`file_summary_by_instance`.`FILE_NAME`)  as `table_name`,
		sum(`performance_schema`.`file_summary_by_instance`.`COUNT_READ`)                            as `count_read`,
		sum(`performance_schema`.`file_summary_by_instance`.`SUM_NUMBER_OF_BYTES_READ`)              as `sum_number_of_bytes_read`,
		sum(`performance_schema`.`file_summary_by_instance`.`SUM_TIMER_READ`)                        as `sum_timer_read`,
		sum(`performance_schema`.`file_summary_by_instance`.`COUNT_WRITE`)                           as `count_write`,
		sum(`performance_schema`.`file_summary_by_instance`.`SUM_NUMBER_OF_BYTES_WRITE`)             as `sum_number_of_bytes_write`,
		sum(`performance_schema`.`file_summary_by_instance`.`SUM_TIMER_WRITE`)                       as `sum_timer_write`,
		sum(`performance_schema`.`file_summary_by_instance`.`COUNT_MISC`)                            as `count_misc`,
		sum(`performance_schema`.`file_summary_by_instance`.`SUM_TIMER_MISC`)                        as `sum_timer_misc`
	from `performance_schema`.`file_summary_by_instance`
	group by `table_schema`,`table_name`;

