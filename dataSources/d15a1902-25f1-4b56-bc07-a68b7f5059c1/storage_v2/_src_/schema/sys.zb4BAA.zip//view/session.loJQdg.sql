create view session as
	select
		`processlist`.`thd_id`                 as `thd_id`,
		`processlist`.`conn_id`                as `conn_id`,
		`processlist`.`user`                   as `user`,
		`processlist`.`db`                     as `db`,
		`processlist`.`command`                as `command`,
		`processlist`.`state`                  as `state`,
		`processlist`.`time`                   as `time`,
		`processlist`.`current_statement`      as `current_statement`,
		`processlist`.`statement_latency`      as `statement_latency`,
		`processlist`.`progress`               as `progress`,
		`processlist`.`lock_latency`           as `lock_latency`,
		`processlist`.`rows_examined`          as `rows_examined`,
		`processlist`.`rows_sent`              as `rows_sent`,
		`processlist`.`rows_affected`          as `rows_affected`,
		`processlist`.`tmp_tables`             as `tmp_tables`,
		`processlist`.`tmp_disk_tables`        as `tmp_disk_tables`,
		`processlist`.`full_scan`              as `full_scan`,
		`processlist`.`last_statement`         as `last_statement`,
		`processlist`.`last_statement_latency` as `last_statement_latency`,
		`processlist`.`current_memory`         as `current_memory`,
		`processlist`.`last_wait`              as `last_wait`,
		`processlist`.`last_wait_latency`      as `last_wait_latency`,
		`processlist`.`source`                 as `source`,
		`processlist`.`trx_latency`            as `trx_latency`,
		`processlist`.`trx_state`              as `trx_state`,
		`processlist`.`trx_autocommit`         as `trx_autocommit`,
		`processlist`.`pid`                    as `pid`,
		`processlist`.`program_name`           as `program_name`
	from `sys`.`processlist`
	where ((`processlist`.`conn_id` is not null) and (`processlist`.`command`<>'Daemon'));

