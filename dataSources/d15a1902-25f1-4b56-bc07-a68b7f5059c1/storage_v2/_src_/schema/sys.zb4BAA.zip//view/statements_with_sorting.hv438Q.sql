create view statements_with_sorting as
	select
		`sys`.`format_statement`(`performance_schema`.`events_statements_summary_by_digest`.`DIGEST_TEXT`)                                                                                        as `query`,
		`performance_schema`.`events_statements_summary_by_digest`.`SCHEMA_NAME`                                                                                                                  as `db`,
		`performance_schema`.`events_statements_summary_by_digest`.`COUNT_STAR`                                                                                                                   as `exec_count`,
		`sys`.`format_time`(`performance_schema`.`events_statements_summary_by_digest`.`SUM_TIMER_WAIT`)                                                                                          as `total_latency`,
		`performance_schema`.`events_statements_summary_by_digest`.`SUM_SORT_MERGE_PASSES`                                                                                                        as `sort_merge_passes`,
		round(ifnull((`performance_schema`.`events_statements_summary_by_digest`.`SUM_SORT_MERGE_PASSES`/nullif(`performance_schema`.`events_statements_summary_by_digest`.`COUNT_STAR`,0)),0),0) as `avg_sort_merges`,
		`performance_schema`.`events_statements_summary_by_digest`.`SUM_SORT_SCAN`                                                                                                                as `sorts_using_scans`,
		`performance_schema`.`events_statements_summary_by_digest`.`SUM_SORT_RANGE`                                                                                                               as `sort_using_range`,
		`performance_schema`.`events_statements_summary_by_digest`.`SUM_SORT_ROWS`                                                                                                                as `rows_sorted`,
		round(ifnull((`performance_schema`.`events_statements_summary_by_digest`.`SUM_SORT_ROWS`/nullif(`performance_schema`.`events_statements_summary_by_digest`.`COUNT_STAR`,0)),0),0)         as `avg_rows_sorted`,
		`performance_schema`.`events_statements_summary_by_digest`.`FIRST_SEEN`                                                                                                                   as `first_seen`,
		`performance_schema`.`events_statements_summary_by_digest`.`LAST_SEEN`                                                                                                                    as `last_seen`,
		`performance_schema`.`events_statements_summary_by_digest`.`DIGEST`                                                                                                                       as `digest`
	from `performance_schema`.`events_statements_summary_by_digest`
	where (`performance_schema`.`events_statements_summary_by_digest`.`SUM_SORT_ROWS`>0)
	order by `performance_schema`.`events_statements_summary_by_digest`.`SUM_TIMER_WAIT` desc;

