create view version as
	select
		'1.5.1'   as `sys_version`,
		version() as `mysql_version`;

