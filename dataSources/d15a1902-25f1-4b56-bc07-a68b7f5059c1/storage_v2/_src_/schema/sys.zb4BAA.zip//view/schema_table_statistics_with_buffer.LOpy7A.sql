create view schema_table_statistics_with_buffer as
	select
		`pst`.`OBJECT_SCHEMA`                                    as `table_schema`,
		`pst`.`OBJECT_NAME`                                      as `table_name`,
		`pst`.`COUNT_FETCH`                                      as `rows_fetched`,
		`sys`.`format_time`(`pst`.`SUM_TIMER_FETCH`)             as `fetch_latency`,
		`pst`.`COUNT_INSERT`                                     as `rows_inserted`,
		`sys`.`format_time`(`pst`.`SUM_TIMER_INSERT`)            as `insert_latency`,
		`pst`.`COUNT_UPDATE`                                     as `rows_updated`,
		`sys`.`format_time`(`pst`.`SUM_TIMER_UPDATE`)            as `update_latency`,
		`pst`.`COUNT_DELETE`                                     as `rows_deleted`,
		`sys`.`format_time`(`pst`.`SUM_TIMER_DELETE`)            as `delete_latency`,
		`fsbi`.`count_read`                                      as `io_read_requests`,
		`sys`.`format_bytes`(`fsbi`.`sum_number_of_bytes_read`)  as `io_read`,
		`sys`.`format_time`(`fsbi`.`sum_timer_read`)             as `io_read_latency`,
		`fsbi`.`count_write`                                     as `io_write_requests`,
		`sys`.`format_bytes`(`fsbi`.`sum_number_of_bytes_write`) as `io_write`,
		`sys`.`format_time`(`fsbi`.`sum_timer_write`)            as `io_write_latency`,
		`fsbi`.`count_misc`                                      as `io_misc_requests`,
		`sys`.`format_time`(`fsbi`.`sum_timer_misc`)             as `io_misc_latency`,
		`sys`.`format_bytes`(`ibp`.`allocated`)                  as `innodb_buffer_allocated`,
		`sys`.`format_bytes`(`ibp`.`data`)                       as `innodb_buffer_data`,
		`sys`.`format_bytes`((`ibp`.`allocated`-`ibp`.`data`))   as `innodb_buffer_free`,
		`ibp`.`pages`                                            as `innodb_buffer_pages`,
		`ibp`.`pages_hashed`                                     as `innodb_buffer_pages_hashed`,
		`ibp`.`pages_old`                                        as `innodb_buffer_pages_old`,
		`ibp`.`rows_cached`                                      as `innodb_buffer_rows_cached`
	from ((`performance_schema`.`table_io_waits_summary_by_table` `pst` left join `sys`.`x$ps_schema_table_statistics_io` `fsbi` on (((`pst`.`OBJECT_SCHEMA`=`fsbi`.`table_schema`) and (`pst`.`OBJECT_NAME`=`fsbi`.`table_name`)))) left join `sys`.`x$innodb_buffer_stats_by_table` `ibp` on (((`pst`.`OBJECT_SCHEMA`=`ibp`.`object_schema`) and (`pst`.`OBJECT_NAME`=`ibp`.`object_name`))))
	order by `pst`.`SUM_TIMER_WAIT` desc;

