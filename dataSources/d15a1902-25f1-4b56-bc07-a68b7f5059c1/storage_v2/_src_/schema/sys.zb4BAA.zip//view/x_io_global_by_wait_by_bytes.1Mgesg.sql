create view `x$io_global_by_wait_by_bytes` as
	select
		substring_index(`performance_schema`.`file_summary_by_event_name`.`EVENT_NAME`,'/',-(2))                                                                            as `event_name`,
		`performance_schema`.`file_summary_by_event_name`.`COUNT_STAR`                                                                                                      as `total`,
		`performance_schema`.`file_summary_by_event_name`.`SUM_TIMER_WAIT`                                                                                                  as `total_latency`,
		`performance_schema`.`file_summary_by_event_name`.`MIN_TIMER_WAIT`                                                                                                  as `min_latency`,
		`performance_schema`.`file_summary_by_event_name`.`AVG_TIMER_WAIT`                                                                                                  as `avg_latency`,
		`performance_schema`.`file_summary_by_event_name`.`MAX_TIMER_WAIT`                                                                                                  as `max_latency`,
		`performance_schema`.`file_summary_by_event_name`.`COUNT_READ`                                                                                                      as `count_read`,
		`performance_schema`.`file_summary_by_event_name`.`SUM_NUMBER_OF_BYTES_READ`                                                                                        as `total_read`,
		ifnull((`performance_schema`.`file_summary_by_event_name`.`SUM_NUMBER_OF_BYTES_READ`/nullif(`performance_schema`.`file_summary_by_event_name`.`COUNT_READ`,0)),0)   as `avg_read`,
		`performance_schema`.`file_summary_by_event_name`.`COUNT_WRITE`                                                                                                     as `count_write`,
		`performance_schema`.`file_summary_by_event_name`.`SUM_NUMBER_OF_BYTES_WRITE`                                                                                       as `total_written`,
		ifnull((`performance_schema`.`file_summary_by_event_name`.`SUM_NUMBER_OF_BYTES_WRITE`/nullif(`performance_schema`.`file_summary_by_event_name`.`COUNT_WRITE`,0)),0) as `avg_written`,
		(`performance_schema`.`file_summary_by_event_name`.`SUM_NUMBER_OF_BYTES_WRITE`+`performance_schema`.`file_summary_by_event_name`.`SUM_NUMBER_OF_BYTES_READ`)        as `total_requested`
	from `performance_schema`.`file_summary_by_event_name`
	where ((`performance_schema`.`file_summary_by_event_name`.`EVENT_NAME` like 'wait/io/file/%') and (`performance_schema`.`file_summary_by_event_name`.`COUNT_STAR`>0))
	order by (`performance_schema`.`file_summary_by_event_name`.`SUM_NUMBER_OF_BYTES_WRITE`+`performance_schema`.`file_summary_by_event_name`.`SUM_NUMBER_OF_BYTES_READ`) desc;

